const form = document.querySelector("#inspect-form");
const input = document.querySelector("#url-input");
const submit = document.querySelector("#submit-btn");
const clear = document.querySelector("#clear-btn");
const errorBox = document.querySelector("#error-box");
const result = document.querySelector("#result");
const destination = document.querySelector("#destination");
const chainList = document.querySelector("#chain-list");
const hopCount = document.querySelector("#hop-count");
const responseMeta = document.querySelector("#response-meta");
const copyBtn = document.querySelector("#copy-btn");
let finalUrl = "";

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
  result.hidden = true;
}
function normalizeUrl(value) {
  const trimmed = value.trim();
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}
function hostLabel(value) {
  try { return new URL(value).hostname; } catch { return value; }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  result.hidden = true;
  const value = input.value.trim();
  if (!value) return showError("Masukkan link yang ingin diperiksa.");
  let normalized;
  try { normalized = normalizeUrl(value); new URL(normalized); }
  catch { return showError("Format URL belum benar. Periksa kembali link kamu."); }

  submit.disabled = true;
  submit.querySelector("span").textContent = "CHECKING...";
  try {
    const response = await fetch("/api/inspect", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ url: normalized })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Gagal memeriksa link.");
    finalUrl = data.destination;
    destination.href = finalUrl;
    destination.textContent = finalUrl;
    responseMeta.textContent = `${data.status} · ${data.contentType}`;
    chainList.replaceChildren();
    data.chain.forEach((item, index) => {
      const li = document.createElement("li");
      const num = document.createElement("span");
      num.className = "chain-num";
      num.textContent = String(index + 1).padStart(2, "0");
      const url = document.createElement("span");
      url.className = "chain-url";
      url.textContent = item.url;
      const status = document.createElement("span");
      status.className = "chain-status";
      status.textContent = `${item.status} ${item.statusText}`.trim();
      li.append(num, url, status);
      chainList.append(li);
    });
    hopCount.textContent = `${Math.max(0, data.chain.length - 1)} HOPS`;
    result.hidden = false;
    result.scrollIntoView({ behavior: "smooth", block: "nearest" });
  } catch (error) {
    showError(error.message);
  } finally {
    submit.disabled = false;
    submit.querySelector("span").textContent = "INSPECT LINK";
  }
});

clear.addEventListener("click", () => {
  input.value = "";
  input.focus();
  errorBox.hidden = true;
  result.hidden = true;
});
copyBtn.addEventListener("click", async () => {
  if (!finalUrl) return;
  try {
    await navigator.clipboard.writeText(finalUrl);
    copyBtn.innerHTML = 'COPIED <span>✓</span>';
    setTimeout(() => copyBtn.innerHTML = 'COPY URL <span>⧉</span>', 1500);
  } catch {
    copyBtn.textContent = "COPY FAILED";
  }
});

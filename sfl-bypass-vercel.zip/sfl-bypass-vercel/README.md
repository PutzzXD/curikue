# SFL Link Inspector — Vercel

Versi siap deploy melalui GitHub + Vercel.

## Deploy dari HP
1. Ekstrak ZIP.
2. Buat repository GitHub baru bernama `sfl-bypass`.
3. Upload seluruh ISI folder ini ke root repository (bukan file ZIP).
4. Buka Vercel dan login dengan GitHub.
5. Pilih Add New → Project, lalu import repository `sfl-bypass`.
6. Framework Preset pilih Other. Biarkan Build Command dan Output Directory kosong.
7. Tekan Deploy dan tunggu selesai.

Buka domain `.vercel.app` yang diberikan Vercel.

## Batasan
Tool memeriksa redirect HTTP standar pada URL publik. Tool tidak melewati CAPTCHA, login, paywall, atau proteksi akses. Beberapa layanan memakai JavaScript atau mekanisme khusus sehingga tujuan akhir mungkin tidak terdeteksi. Gunakan hanya pada link yang boleh kamu periksa.

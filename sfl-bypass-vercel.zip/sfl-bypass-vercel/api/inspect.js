const dns = require("node:dns").promises;
const net = require("node:net");
const MAX_REDIRECTS = 8;
const TIMEOUT_MS = 10000;

function privateIPv4(ip) {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return true;
  return p[0] === 10 || p[0] === 127 || p[0] === 0 ||
    (p[0] === 169 && p[1] === 254) ||
    (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) ||
    (p[0] === 100 && p[1] >= 64 && p[1] <= 127) || p[0] >= 224;
}
function privateIPv6(ip) {
  const x = ip.toLowerCase();
  return x === "::1" || x === "::" || x.startsWith("fc") || x.startsWith("fd") ||
    x.startsWith("fe80:") || x.startsWith("::ffff:127.");
}
async function validatePublicUrl(url) {
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Hanya URL HTTP atau HTTPS yang didukung.");
  if (url.username || url.password) throw new Error("URL dengan kredensial tidak diizinkan.");
  const host = url.hostname.replace(/^\[|\]$/g, "");
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) throw new Error("Alamat lokal tidak diizinkan.");
  const type = net.isIP(host);
  if (type === 4 && privateIPv4(host)) throw new Error("Alamat IP privat tidak diizinkan.");
  if (type === 6 && privateIPv6(host)) throw new Error("Alamat IP privat tidak diizinkan.");
  if (!type) {
    const records = await dns.lookup(host, { all: true, verbatim: true });
    if (!records.length || records.some(r => r.family === 4 ? privateIPv4(r.address) : privateIPv6(r.address)))
      throw new Error("Host tidak valid atau mengarah ke jaringan privat.");
  }
}
async function inspect(raw) {
  let current;
  try { current = new URL(raw); } catch { throw new Error("Format URL tidak valid."); }
  const chain = [];
  for (let i = 0; i <= MAX_REDIRECTS; i++) {
    await validatePublicUrl(current);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    let response;
    try {
      response = await fetch(current, {
        method: "GET", redirect: "manual", signal: controller.signal,
        headers: { "user-agent": "SFL-Link-Inspector/1.1", "accept": "text/html,application/xhtml+xml,*/*;q=0.8" }
      });
    } catch (err) {
      if (err.name === "AbortError") throw new Error("Server terlalu lama merespons.");
      throw new Error("Link tidak dapat diakses. Periksa URL atau coba lagi.");
    } finally { clearTimeout(timer); }
    chain.push({ url: current.href, status: response.status, statusText: response.statusText || "" });
    const location = response.headers.get("location");
    if ([301, 302, 303, 307, 308].includes(response.status) && location) {
      if (i === MAX_REDIRECTS) throw new Error("Terlalu banyak redirect (maksimal 8).");
      current = new URL(location, current);
      continue;
    }
    if (response.body) await response.body.cancel().catch(() => {});
    return { original: raw, destination: current.href, status: response.status,
      contentType: response.headers.get("content-type") || "Tidak diketahui", chain };
  }
  throw new Error("Pemeriksaan redirect tidak selesai.");
}
module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed." });
  }
  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const value = body && body.url;
    if (typeof value !== "string" || !value.trim() || value.length > 2048)
      return res.status(400).json({ error: "Masukkan URL yang valid (maksimal 2048 karakter)." });
    return res.status(200).json(await inspect(value.trim()));
  } catch (err) {
    return res.status(400).json({ error: err.message || "Terjadi kesalahan saat memeriksa URL." });
  }
};
